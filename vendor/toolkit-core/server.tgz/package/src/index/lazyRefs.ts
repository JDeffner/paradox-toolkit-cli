/**
 * On-demand reference search over roots that are NOT reference-indexed up
 * front: vanilla and read-only dependency parents (rework plan AD-4). Keeping
 * those out of the persistent ReferenceIndex is a memory guard (vanilla alone
 * holds hundreds of thousands of usage sites); find-references still has to
 * SHOW them (#3), so this scanner greps the roots for one name at a time.
 *
 * Exact-token hits are classified by the same grammar and schema as navigation: script values, trigger/effect arguments and loc-key values
 * are all real usage sites even where the schema has no ref-field for the
 * enclosing key. Column-0 keys are skipped — those are the definition sites,
 * which the provider appends separately under includeDeclaration.
 *
 * Costs are bounded three ways: the per-root file list is enumerated once,
 * lines are tokenized only when a cheap substring test hits, and results are
 * memoized per name until a root or file changes. First lookup of a name pays one
 * pass of disk reads; repeats are O(1).
 *
 * No `vscode` imports here: unit-tested in plain Node.
 */
import * as fs from "fs";
import * as path from "path";
import type { DefSource, Reference } from "@px-lsp/protocol/types";
import { iterFilesInRoots, listFiles } from "@px-lsp/protocol/fsWalk";
import { isStructuralKeyword } from "../contextKeywords";
import { activeProfile } from "../games/active";
import { loadSchema, type SchemaData } from "../schema/loader";
import { expectedKindsAt } from "../features/symbolResolution";
import { TextDocument } from "vscode-languageserver-textdocument";
import { URI } from "vscode-uri";
import { evictParse } from "../parseCache";

export interface LazyRefRoot {
  root: string;
  source: DefSource;
}

/** Memoized names kept per roots generation (FIFO eviction). */
const CACHE_CAP = 64;
/** Files read per event-loop turn. */
const BATCH = 200;
/** Result cap per name: protects the peek widget and memory from a lookup on
 * a near-universal name; real identifiers stay far below it. */
const MAX_REFS = 5000;

const NAME_OK = /^[A-Za-z0-9_][A-Za-z0-9_.-]*$/;
/** Identifier characters: a hit is a token only when NOT flanked by these. */
const IDENT = /[A-Za-z0-9_.-]/;

const yieldNow = () => new Promise<void>((resolve) => setImmediate(resolve));

export class LazyReferenceScanner {
  private roots: LazyRefRoot[] = [];
  private indexAssets = true;
  private isEngineToken?: (name: string) => boolean;
  private fileLists = new Map<string, string[]>();
  private cache = new Map<string, Promise<Reference[]>>();
  private schema = loadSchema(null);
  private generation = 0;

  /** Reconfigure (on reindex/settings change): drops all memoized results. */
  setRoots(
    roots: LazyRefRoot[],
    isEngineToken?: (name: string) => boolean,
    indexAssets = true,
    schema: SchemaData = loadSchema(null)
  ): void {
    this.roots = roots;
    this.indexAssets = indexAssets;
    this.schema = schema;
    this.generation++;
    this.isEngineToken = isEngineToken;
    this.fileLists.clear();
    this.cache.clear();
  }

  invalidateFile(file: string): void {
    for (const { root } of this.roots) {
      const relative = path.relative(root, file);
      if (relative.startsWith("..") || path.isAbsolute(relative)) continue;
      this.fileLists.delete(root);
      this.cache.clear();
      this.generation++;
      break;
    }
  }

  /** All usage sites of `name` across the configured roots. Engine tokens and
   * structural grammar keywords are excluded: they appear in nearly every
   * file, and their documentation comes from script_docs, not the index.
   * (isStructuralKeyword, not classifyKeyword: the latter's naming-convention
   * buckets would swallow every *_trigger-named scripted trigger, #5.) */
  lookup(name: string): Promise<Reference[]> {
    if (
      this.roots.length === 0 ||
      name.length < 2 ||
      !NAME_OK.test(name) ||
      isStructuralKeyword(name) ||
      this.isEngineToken?.(name)
    ) {
      return Promise.resolve([]);
    }
    let pending = this.cache.get(name);
    if (!pending) {
      pending = this.scan(name);
      // FIFO eviction: Map iteration order is insertion order.
      if (this.cache.size >= CACHE_CAP) {
        const oldest = this.cache.keys().next().value;
        if (oldest !== undefined) this.cache.delete(oldest);
      }
      this.cache.set(name, pending);
    }
    return pending;
  }

  private filesOf(root: string): string[] {
    let files = this.fileLists.get(root);
    if (!files) {
      const scriptRoots = this.schema.entries
        .filter((entry) => (entry.ext ?? ".txt") === ".txt")
        .map((entry) => path.join(root, entry.path));
      files = [];
      for (const file of iterFilesInRoots([...scriptRoots, root], ".txt")) {
        if (file !== null) files.push(file);
      }
      for (const entry of activeProfile().schema) {
        if (!this.indexAssets && entry.ext?.toLowerCase() === ".asset") continue;
        if (entry.extraction === "named-block" && entry.ext && entry.ext !== ".txt") {
          files.push(...listFiles(path.join(root, entry.path), entry.ext));
        }
      }
      this.fileLists.set(root, files);
    }
    return files;
  }

  private async scan(name: string): Promise<Reference[]> {
    const generation = this.generation;
    const out: Reference[] = [];
    for (const { root } of this.roots) {
      const files = this.filesOf(root);
      for (let i = 0; i < files.length; i += BATCH) {
        for (const file of files.slice(i, i + BATCH)) {
          let content: string;
          try {
            content = fs.readFileSync(file, "utf8");
          } catch {
            continue;
          }
          if (!content.includes(name)) continue;
          const hits: Reference[] = [];
          scanContent(content, name, file, hits);
          // Disk scans must not reuse or evict an open editor's versioned parse.
          const document = TextDocument.create(
            URI.file(file).with({ query: "px-lazy-refs" }).toString(),
            "paradox",
            generation,
            content
          );
          for (const hit of hits) {
            const kinds = expectedKindsAt(
              document,
              { line: hit.line, character: hit.startChar },
              this.schema
            );
            if (kinds?.length === 0) continue;
            hit.kinds = kinds ?? [];
            out.push(hit);
          }
          evictParse(document.uri);
          if (out.length >= MAX_REFS) return out.slice(0, MAX_REFS);
        }
        await yieldNow();
        if (generation !== this.generation) return this.lookup(name);
      }
    }
    return out;
  }
}

/** Exact-token occurrences of `name` in `content`, appended to `out`. */
export function scanContent(content: string, name: string, file: string, out: Reference[]): void {
  const lines = content.split("\n");
  for (let lineNo = 0; lineNo < lines.length; lineNo++) {
    let line = lines[lineNo];
    if (!line.includes(name)) continue;
    // Strip comments; # inside a string is rare enough to accept the miss.
    const hash = line.indexOf("#");
    if (hash >= 0) line = line.slice(0, hash);
    let from = 0;
    for (;;) {
      const at = line.indexOf(name, from);
      if (at < 0) break;
      from = at + name.length;
      if (at > 0 && IDENT.test(line[at - 1])) continue;
      const after = line[at + name.length];
      if (after !== undefined && IDENT.test(after)) continue;
      // Column-0 keys are definition sites (top-level assignments), not uses.
      if (at === 0) continue;
      out.push({
        name,
        kinds: [],
        file,
        line: lineNo,
        startChar: at,
        endChar: at + name.length,
      });
    }
  }
}
