/**
 * The game type schema (rework plan AD-3): a *small*, declarative,
 * community-editable table describing what lives in each game folder, how
 * definitions are named, which loc keys a type requires, what scope its
 * script blocks run in, and which assignment keys cross-reference other
 * definitions.
 *
 * This is deliberately NOT a validation-rule language (that was CWTools'
 * mistake); deep semantic validation is the tiger validator's job. The schema feeds
 * navigation, completion, hover, references, rename, coverage and (very
 * conservative) structural diagnostics.
 */

/** How definition names are extracted from files in a folder. */
export type NameExtraction =
  /** One definition per top-level assignment key (`my_thing = { ... }`). */
  | "top-level-key"
  /** Repeated top-level blocks whose identity is their direct `name` field. */
  | "named-block"
  /** Event files: only `namespace.NNN` top-level keys are definitions. */
  | "event-id"
  /** Landed titles: keys matching /^[ekdcb]_/ at any nesting depth. */
  | "nested-title"
  /** GUI files: `type X = base { ... }` and `template X { ... }` statements. */
  | "gui-type"
  /** Localization yml entries. */
  | "loc-key";

/**
 * One documented key inside a definition's body or a named sub-block (v1.1 §B2).
 * `values` is a coarse value hint ("enum:a|b|c" for enumerations); `freq` is the
 * per-context usage count used for ranking (Workstream C).
 */
export interface KeySpec {
  key: string;
  doc?: string;
  values?: "loc" | "bool" | "block" | `enum:${string}`;
  freq?: number;
  /**
   * Root scope of the block this key opens, when the game's `_*.info` doc
   * declares one (`# root = the activity` → "activity"). Scope inference sets
   * the current scope to this when walking through the key.
   */
  scope?: string;
  /**
   * Hand-curated entry (structures.ts): its position in the curated list is
   * deliberate and outranks any harvested key. Harvested `.info` freqs count
   * usage at ANY depth in the folder, so re-sorting curated top-level keys by
   * them lets option-level keys (name, modifier…) bury the real top-level
   * vocabulary, the completion regression rank-eval caught in 2026-07.
   */
  curated?: boolean;
  /**
   * Definition kinds this key's value names, where a global `RefField` would
   * be wrong because the key means different things in different folders
   * (`opposites` is a trait list here and a scripted_relation list there).
   * Per-kind and therefore unambiguous; read by the creators' form request.
   */
  refKinds?: string[];
}

/** The document shape of a definition kind: top-level keys plus named sub-blocks. */
export interface StructureSpec {
  topLevel: KeySpec[];
  /** Named sub-blocks (option, send_option, cost…) with their own keys. */
  blocks?: Record<string, KeySpec[]>;
}

/**
 * How one definition kind declares the root scope of its own script blocks
 * (scopes/inference.ts). Games disagree on both the key and the vocabulary: one
 * writes `scope = character` inside an event, another writes `type = X_event`.
 * That is why this table lives on the game profile and not in the engine,
 * assuming one game's spelling everywhere puts every event of the other game in
 * the wrong root scope, which demotes every correct effect to "other scope" and
 * sinks it to the bottom of completion.
 */
export interface DefRootKey {
  /** Key inside the definition body that names the root scope. */
  key: string;
  /** Scope when the key is absent. Omit = fall back to the schema's rootScopes. */
  default?: string;
  /**
   * Declared value → scope name, for games that do not spell the value as the
   * scope (`country_event` → country). Absent = the value IS the scope name.
   * A value the map does not list falls back to `default`.
   */
  values?: Record<string, string>;
}

/** An engine-provided saved scope available in a kind's script blocks (v1.1 §B3). */
export interface AmbientScope {
  name: string;
  type: string;
  doc: string;
}

export interface SchemaEntry {
  /** Graphics property vocabulary harvested from this game's .asset corpus. */
  assetVocabulary?: Record<string, Record<string, number>>;
  /** Context path + field -> graphics-specific meaning and target namespace. */
  assetFields?: Record<string, AssetField>;
  assetEnginePaths?: string[];
  /** Folder relative to the game/mod root, forward slashes, no trailing slash. */
  path: string;
  /** Definition kind, singular snake_case (e.g. "trait", "decision"). */
  kind: string;
  /** File extension, default ".txt". */
  ext?: string;
  /** Name extraction mode, default "top-level-key". */
  extraction?: NameExtraction;
  /** A direct scalar field identifies an alternate top-level database kind. */
  kindByField?: { field: string; kind: string; otherwise: string };
  /** Additional named blocks inside each top-level definition, at an exact wrapper path. */
  nestedDefinitions?: {
    kind: string;
    /** Empty for direct child blocks; otherwise the named wrappers below the top-level definition. */
    path: string[];
    /** Group properties whose block values are not definitions. */
    excludedKeys?: string[];
  };
  /** Named-block fields that refer to another named block, rather than script calls. */
  referenceKeys?: string[];
  /** File-valued fields and allowed extensions, verified in the game's asset files. */
  fileFields?: Record<string, string[]>;
  /**
   * Loc keys the game requires per definition; `$` is the definition name
   * (e.g. "trait_$", "$_desc"). Used for conservative missing-loc diagnostics
   * and loc coverage, only include patterns that ≥95% of vanilla definitions
   * of this kind actually define.
   */
  requiredLoc?: string[];
  /**
   * Every loc key the game generates for a definition of this kind, `$` = the
   * name, as the folder's `_*.info` doc states them. A SUPERSET of
   * `requiredLoc`, which may only carry the patterns ≥95% of vanilla actually
   * defines because a diagnostic hangs off it; a creator writes the whole set
   * and asks the modder for each. Absent = `requiredLoc` is the whole set.
   */
  locPatterns?: string[];
  /**
   * Where the game looks for a definition's default icon, relative to the
   * game/mod root, forward slashes, no trailing slash. Only set where the
   * folder's `_*.info` doc states the path; absent = this kind has no
   * name-derived icon and a creator offers no icon picker for it.
   */
  iconFolder?: string;
  /**
   * Key inside a definition's body whose value sorts this kind's definitions
   * into families, when one folder holds several (`type = ethos` in
   * common/culture/pillars). A creator that draws one picker per family reads
   * it through paradox/definitionForm; nothing else does. Absent = the kind is
   * one flat list.
   */
  groupKey?: string;
  /** Scope(s) a definition of this type pushes as root in its script blocks (Phase 3). */
  rootScopes?: string[];
  /** Include definitions of this kind in completion lists (default true).
   * False for huge/noisy kinds (history characters, provinces). */
  completable?: boolean;
  /**
   * Block-local structural keys for this kind (v1.1 §B2). Sourced from the game's
   * `_*.info` files. Static, not harvested at runtime. Not yet overlayable (F5).
   */
  structure?: StructureSpec;
  /** Engine-provided saved scopes for this kind (v1.1 §B3). Not yet overlayable (F5). */
  ambientScopes?: AmbientScope[];
}

export function definitionKinds(entry: SchemaEntry): string[] {
  return [
    ...new Set(
      [
        entry.kind,
        entry.nestedDefinitions?.kind,
        entry.kindByField?.kind,
        entry.kindByField?.otherwise,
      ].filter((kind): kind is string => !!kind)
    ),
  ];
}

export interface AssetField {
  doc: string;
  files?: string[];
  target?: {
    kind?: string;
    block: string;
    /** A declaration local to this owning block, reached via a named reference if needed. */
    owner?: string;
    via?: string;
    key?: string;
    imports?: { block: string; typeKey: string; nameKey: string; type: string };
  };
  /** Effect names are local to the shader file named by this sibling property. */
  shaderFile?: string;
}

/** Form a cross-reference field takes. */
export type RefFieldForm =
  /** `key = name` */
  | "scalar"
  /** `key = { name_a name_b ... }` */
  | "list"
  /** either of the above */
  | "both";

/** An assignment key whose value references definitions of the given kinds. */
export interface RefField {
  key: string;
  kinds: string[];
  form?: RefFieldForm; // default "scalar"
  /** List also accepts weighted entries (`<number> = name`), like random_events. */
  weighted?: boolean;
}

/** JSON shape of the optional workspace overlay at <configDir>/schema.json. */
export interface SchemaOverlay {
  entries?: SchemaEntry[];
  refFields?: RefField[];
  prefixRefs?: Record<string, string[]>;
}
